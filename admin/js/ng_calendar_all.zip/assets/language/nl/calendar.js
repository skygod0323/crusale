/*
 * NoGray JavaScript Library v1.0
 * http://www.NoGray.com
 *
 * Copyright (c) 2009 Wesam Saif
 * http://www.nogray.com/license.php
 */

ng.Language.set_language('nl', {
	// calendar component
	view_selected_dates:'Bekijk Geselecteerde Data',
	hide_selected_dates:'Verberg Geselecteerde Data'
});
